const express = require("express");
const authMiddleware = require("../middleware/auth");
const User = require("../models/user");

const router = express.Router();


router.get("/matches", authMiddleware, async (req, res) => {
  try {
  
    const user = await User.findById(req.user.userId);
    const userHobbies = user.hobbies;

    // Find users with similar hobbies and not blocked
    const matches = await User.find({
      hobbies: { $in: userHobbies },
      _id: { $ne: user._id },
      gender: { $ne: user.gender },
      blocked: { $ne: true },
    });

    res.status(200).json({ matches: matches });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
